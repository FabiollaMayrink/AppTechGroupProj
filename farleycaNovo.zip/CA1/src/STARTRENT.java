/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author farley_reis
 */

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * 
 * @author gabriel
 */
public final class STARTRENT {

    private ResourceBundle bundle = null;
    
    public STARTRENT(String idioma) {     	    	    	

    }
    
    public ResourceBundle getLocale() {
        return bundle;
    }
}